# EUROGAM — Site vitrine

Site vitrine B2B pour EUROGAM, distributeur de pièces automobiles pour professionnels.
Joué-lès-Tours, Indre-et-Loire (37).

## Structure

```
eurogam-final/
├── index.html              ← Site complet (HTML + CSS + JS inline)
├── images/
│   ├── logo.jpg            ← Logo officiel EUROGAM
│   ├── entrepot.png        ← Photo entrepôt (hero + bannières)
│   ├── flyer-janvier.jpg   ← Flyer offre janvier
│   ├── flyer-juin.png      ← Flyer offre juin
│   ├── flyer-mai.png       ← Flyer offre mai
│   ├── flyer-juillet.jpg   ← Flyer offre juillet
│   ├── produits/           ← Images des 15 catégories produits
│   │   ├── freinage.svg
│   │   ├── filtration.svg
│   │   └── ... (15 fichiers)
│   └── marques/            ← Logos des marques (à ajouter)
│       ├── bosch.png       ← À fournir
│       ├── sasic.png       ← À fournir
│       └── ...
└── README.md
```

## Lancer le site

Ouvrir `index.html` dans un navigateur.  
Ou lancer un serveur local :
```bash
python3 -m http.server 8080
```
Puis ouvrir http://localhost:8080

## Administration des offres

1. Aller sur la page **Offres**
2. Cliquer **⚙ Administration** (bas de page)
3. Mot de passe : `RodusedeuroG`
4. Modifier texte, images, ordre des offres
5. Cliquer **Enregistrer & Publier**

Les modifications sont sauvegardées automatiquement (localStorage).

## Informations à compléter

- `[ADRESSE EMAIL À RENSEIGNER]` → email EUROGAM
- `[HORAIRES À RENSEIGNER]` → horaires d'ouverture
- `[NOM DU RESPONSABLE À RENSEIGNER]` → directeur publication
- Page Équipe → noms et fonctions des 7 collaborateurs
- `images/marques/` → logos des marques à déposer

## Déploiement GitHub Pages

```bash
git init
git add .
git commit -m "Site EUROGAM v1"
git remote add origin https://github.com/VOTRE_COMPTE/eurogam.git
git push -u origin main
```

Activer GitHub Pages dans Settings → Pages → Source: main branch.
